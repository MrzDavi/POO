public class Exec {
    public static void main(String[] args) {

      Soma b =  new Soma();
        b.calcula();
        
      
    
}
}
