public class Main {
    public static void main(String[] args){

        Animal n1=new Pollo();

        n1.info();
        };
    }
    

