public interface Animal{
    
    public boolean sleepin=true;
    public void eatin();
    public void playin();
    public void info();
        
}