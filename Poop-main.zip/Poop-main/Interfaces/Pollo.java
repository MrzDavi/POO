    public class Pollo implements Animal{
       
      public Pollo(){}
        
        public void eatin(){}
        public void playng(){}
        public void playin(){}
        public void info(){
            System.out.printf("Sono:%s%n",this.sleepin ? "Yes" : "No");
    }
  }

